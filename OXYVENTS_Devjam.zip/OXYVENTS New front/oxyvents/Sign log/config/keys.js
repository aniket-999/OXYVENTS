module.exports = {
    MongoURI : 'mongodb+srv://Eagle:abhinav@oxyvents.tniy9.mongodb.net/oxyvents?retryWrites=true&w=majority'
}